db.createUser({
    user: "admin",
    pwd: "p@ssw0rd",
    roles: ["userAdminAnyDatabase"],
});
