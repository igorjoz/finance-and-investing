db.createUser({
    user: "wai_web",
    pwd: "w@i_w3b",
    roles: ["readWrite", "dbAdmin"]
});
