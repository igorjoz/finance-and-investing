<main class="page__main">
    <article class="page__article">
        <header class="page__article-header">
            <h1 class="page__article-header-text">
                Frequently Asked Questions
            </h1>
        </header>

        <div class="page__accordion">
            <h2 class="page__section-header">
                What's the best time to start investing?
            </h2>
            <div>
                <p class="page__section-paragraph">
                    The best time to start investing is now. The sooner you start, the more time you have to take
                    advantage of
                    the <span class="page__bold-text">power of compounding</span>. The longer you invest, the
                    more time your money has to grow.
                </p>

                <p class="page__section-paragraph">
                    Important note: first you need to <span class="page__bold-text">get rid of your debt</span>. If
                    you
                    have any debt, pay it off first, then build up your emergency fund, and then start investing.
                </p>
            </div>

            <h2 class="page__section-header">
                What should I invest $10'000 in?
            </h2>
            <div>
                <p class="page__section-paragraph">
                    Well, it depends. First, you should create a strategy, think about your goals, and then invest
                    according to your strategy. Start with emergency fund, then build your financial cushion, then
                    invest in your long-term portfolio. If you want take more risk - consider creating offensive
                    portfolio.
                </p>

                <p class="page__section-paragraph">
                    Important note: first you need to <span class="page__bold-text">get rid of your debt</span>. If
                    you
                    have any debt, pay it off first, then build up your emergency fund, and then start investing.
                </p>
            </div>
        </div>

        <!-- <section class="page__section" id="whats-the-best-time-to-start-investing">
            <h2 class="page__section-header">
                What's the best time to start investing?
            </h2>

            <p class="page__section-paragraph">
                The best time to start investing is now. The sooner you start, the more time you have to take
                advantage of
                the <span class="page__bold-text">power of compounding</span>. The longer you invest, the
                more time your money has to grow.
            </p>

            <p class="page__section-paragraph">
                Important note: first you need to <span class="page__bold-text">get rid of your debt</span>. If you
                have any debt, pay it off first, then build up your emergency fund, and then start investing.
            </p>
        </section> -->

        <section class="page__section" id="what-is-inflation-and-how-does-it-work">
            <h2 class="page__section-header">
                What is inflation and how does it work?
            </h2>

            <p class="page__section-paragraph">
                Inflation is the rate at which the general level of prices for goods and services is rising and,
                subsequently, the purchasing power of currency is falling. Inflation is a hidden tax that erodes
                your purchasing power. It is important to understand that inflation is not a one-time event. It
                is a continuous process that occurs over time.
            </p>

            <p class="page__section-paragraph">
                Polish central bank (Narodowy Bank Polski) has set the inflation target at 2.5%, which in long run
                (20 years)
                seems to be maintained.
            </p>

            <p class="page__section-paragraph">
                Check out how very high inflation affects products' prices over the years. The inicial price is $100
                and we assume inflation of 17.9% per year (October inflation value recorded in Poland).
            </p>

            <div class="page__image-wrapper">
                <img src="../images/inflation-over-time.png" class="page__image"
                    alt="Chart presentig effects of high infaltion rates">
            </div>

            <table class="table">
                <thead class="table__head">
                    <tr class="table__row">
                        <th scope="col">Year</th>
                        <th scope="col">Price</th>
                        <th scope="col">Inflation rate that year</th>
                        <th scope="col">Cumulative inflation</th>
                    </tr>
                </thead>
                <tbody class="table__body">
                    <tr class="table__row">
                        <th scope="row" class="table__cell">1</th>
                        <td class="table__cell">$100</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">100.00%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">2</th>
                        <td class="table__cell">$117.90</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">117.90%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">3</th>
                        <td class="table__cell">$139.00</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">139.00%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">4</th>
                        <td class="table__cell">$163.89</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">163.89%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">5</th>
                        <td class="table__cell">$193.22</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">193.22%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">6</th>
                        <td class="table__cell">$227.81</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">227.81%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">7</th>
                        <td class="table__cell">$268.59</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">268.59%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">8</th>
                        <td class="table__cell">$316.66</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">316.66%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">9</th>
                        <td class="table__cell">$373.35</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">373.35%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">10</th>
                        <td class="table__cell">$440.17</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">440.17%</td>
                    </tr>

                    <tr class="table__row">
                        <th scope="row" class="table__cell">11</th>
                        <td class="table__cell">$518.96</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">518.96%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">12</th>
                        <td class="table__cell">$611.86</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">611.86%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">13</th>
                        <td class="table__cell">$721.8</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">721.38%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">14</th>
                        <td class="table__cell">$850.51</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">850.51%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">15</th>
                        <td class="table__cell">$1002.75</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">1002.75%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">16</th>
                        <td class="table__cell">$1182.24</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">1182.24%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">17</th>
                        <td class="table__cell">$1393.87</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">1393.87%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">18</th>
                        <td class="table__cell">$1643.37</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">1643.37%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">19</th>
                        <td class="table__cell">$1937.53</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">1937.53%</td>
                    </tr>

                    <tr>
                        <th scope="row" class="table__cell">20</th>
                        <td class="table__cell">$2284.35</td>
                        <td class="table__cell">17.9%</td>
                        <td class="table__cell">2284.35%</td>
                    </tr>
                </tbody>
            </table>

            <p class="page__section-paragraph">
                As you can see, inflation is very dangerous in longer periods of time, because the cumulative
                inflation grows exponentially. In 20 years with inflation rate of 17.9% the price grew 22.8 times.
                It means that your saving are now work for you 22.8 times less than they did 20 years ago.
            </p>
        </section>

        <!-- <section class="page__section" id="what-should-i-invest-$10000-in">
            <h2 class="page__section-header">
                What should I invest $10'000 in?
            </h2>

            <p class="page__section-paragraph">
                Well, it depends. First, you should create a strategy, think about your goals, and then invest
                according to your strategy. Start with emergency fund, then build your financial cushion, then
                invest in your long-term portfolio. If you want take more risk - consider creating offensive
                portfolio.
            </p>

            <p class="page__section-paragraph">
                Important note: first you need to <span class="page__bold-text">get rid of your debt</span>. If you
                have any debt, pay it off first, then build up your emergency fund, and then start investing.
            </p>
        </section> -->
    </article>
</main>