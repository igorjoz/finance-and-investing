<h1>
    Error
</h1>

<p>
    <?= $error_message ?>
</p>