<main class="page__main">
    <article class="page__article">
        <header class="page__article-header">
            <h1 class="page__article-header-text">
                Send me a message!
            </h1>
        </header>

        <section class="page__section">
            <form action="send-contact-form.php" class="form" method="post">
                <div class="form-group form__input-and-label-wrapper">
                    <label for="nameAndSurname">
                        Name and surname
                    </label>

                    <input type="text" class="form-control form__input" id="nameAndSurname" name="nameAndSurname"
                        required>
                </div>

                <div class="form-group">
                    <label for="email">
                        Email address
                    </label>

                    <input type="email" class="form-control form__input" id="email" name="email" required>
                </div>

                <div class="form-group">
                    <label for="phone">
                        <a href="#" class="page__tooltip"
                            title="If your preferred contact method is phone, please provide us your phone number">
                            Phone number (optional)
                        </a>
                    </label>

                    <input type="tel" class="form-control form__input" id="phone" name="phone">
                </div>

                <p class="form__radio-description">
                    Preferred contact method
                </p>

                <div class="form__radio-options-wrapper">
                    <div class="form-group form__input-and-label-wrapper">
                        <input class="form-check-input" type="radio" name="contact_method" id="method_email"
                            value="email" checked>

                        <label class="form-check-label form__label form__label--radio" for="method_email">
                            Email
                        </label>
                    </div>

                    <div class="form-group form__input-and-label-wrapper">
                        <input class="form-check-input" type="radio" name="contact_method" id="method_phone"
                            value="phone">

                        <label class="form-check-label form__label form__label--radio" for="method_phone">
                            Phone
                        </label>
                    </div>
                </div>

                <div class="form-group form__input-and-label-wrapper">
                    <label class="form-check-label" for="inlineFormCustomSelect">Topic of the message</label>
                    <select class="custom-select form-check-label form__input" id="inlineFormCustomSelect" required>
                        <option value="" selected>Choose...</option>
                        <option value="1">Personal Finance</option>
                        <option value="2">Investing</option>
                        <option value="3">Collaboration with me</option>
                        <option value="4">Regarding the website</option>
                        <option value="5">Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="message">Message</label>

                    <textarea class="form-control form__textarea" id="message" name="message" rows="8"
                        required></textarea>
                </div>

                <div class="form-group form__input-and-label-wrapper form__input-and-label-wrapper--accept-rules">
                    <input class="form-check-input" type="checkbox" value="" id="rulesAccept" name="rulesAccept">

                    <label class="form-check-label form__label form__label--accept-rules" for="rulesAccept">
                        I accept the terms and conditions
                    </label>
                </div>

                <button type="reset" class="btn btn-secondary form__reset-button">
                    Reset the form
                </button>

                <button type="submit" class="btn btn-primary form__submit-button">
                    Send message
                </button>
            </form>
        </section>
    </article>
</main>