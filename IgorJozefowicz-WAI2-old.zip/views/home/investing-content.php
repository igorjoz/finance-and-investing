<main class="page__main">
    <article class="page__article">
        <header class="page__article-header">
            <h1 class="page__article-header-text">
                Basics of Investing
            </h1>
        </header>

        <section class="page__section" id="types-of-assets">
            <h2 class="page__section-header">
                Types of assets & ways of investing
            </h2>

            <ul class="investing__list">
                <li class="investing__list-item investing__list-item--bigger-text">
                    shares
                    <ul class="investing__nested-list">
                        <li class="investing__nested-list-item">
                            ETFs (exchange-traded funds)
                        </li>
                        <li class="investing__nested-list-item">
                            shares of individual companies
                        </li>
                        <li class="investing__nested-list-item">
                            commodity futures contracts
                        </li>
                    </ul>
                </li>

                <li class="investing__list-item investing__list-item--bigger-text">
                    bonds
                    <ul class="investing__nested-list">
                        <li class="investing__nested-list-item">
                            treasury bonds: inflation-indexed or with fixed rate
                        </li>
                        <li class="investing__nested-list-item">
                            corporate bonds
                        </li>
                    </ul>
                </li>

                <li class="investing__list-item investing__list-item--bigger-text">
                    real estate
                    <ul class="investing__nested-list">
                        <li class="investing__nested-list-item">
                            apartments for rent
                        </li>
                        <li class="investing__nested-list-item">
                            flipping houses
                        </li>
                        <li class="investing__nested-list-item">
                            investment ground
                        </li>
                    </ul>
                </li>

                <li class="investing__list-item investing__list-item--bigger-text">
                    raw materials
                    <ul class="investing__nested-list">
                        <li class="investing__nested-list-item">
                            gold, silver
                        </li>
                        <li class="investing__nested-list-item">
                            crude oil, natural gas
                        </li>
                    </ul>
                </li>

                <li class="investing__list-item investing__list-item--bigger-text">
                    foreign currencies
                </li>

                <li class="investing__list-item investing__list-item--bigger-text">
                    cryptocurrencies
                </li>

                <li class="investing__list-item investing__list-item--bigger-text">
                    ...and many more others
                </li>
            </ul>
        </section>

        <section class="page__section" id="types-of-portfolios">
            <h2 class="page__section-header">
                Types of portfolios & recommended division
            </h2>

            <ul class="investing__list">
                <li class="investing__list-item investing__list-item--bigger-text">
                    financial cushion
                    <ul class="investing__nested-list">
                        <li class="investing__nested-list-item">
                            basic requirement for a peaceful and secure life, so that you are no longer a slave to
                            your employer and the financial system
                        </li>
                        <li class="investing__nested-list-item">
                            should be enough to cover your expenses for about 3 to 12 months (depending on your
                            risk tolerance)
                        </li>
                        <li class="investing__nested-list-item">
                            should be invested in safe assets
                        </li>
                        <li class="investing__nested-list-item">
                            about 25% should be kept as cash or in a bank savings or deposit account
                        </li>
                        <li class="investing__nested-list-item">
                            about 75% should be held in government bonds, which are relatively very safe
                        </li>
                        <li class="investing__nested-list-item">
                            encourages you to follow your ideas in a career, e.g. you no longer have to worry about
                            losing your job, because you have enough money to live on for next 6 months
                        </li>
                    </ul>
                </li>

                <li class="investing__list-item investing__list-item--bigger-text">
                    long-term (defensive) portfolio
                    <ul class="investing__nested-list">
                        <li class="investing__nested-list-item">
                            main portfolio, which should be invested in diversified assets
                        </li>
                        <li class="investing__nested-list-item">
                            its main purpose is to grow your money over time in a stable manner, without need to
                            spend many hours on it
                        </li>
                        <li class="investing__nested-list-item">
                            a good target is 3% above inflation
                        </li>
                        <li class="investing__nested-list-item">
                            you should define wages (and acceptable ranges) for every asset in your portfolio to
                            automate the investment process and avoid being fooled by your feelings or environment
                        </li>
                        <li class="investing__nested-list-item">
                            there are many assets you can invest in, but a popular one is to invest 50% in financial
                            instruments and 50% in real estate
                        </li>
                        <li class="investing__nested-list-item">
                            don't worry about the 100% exact division of your portfolio, you don't have to buy
                            properties
                            right away, you can start with financial instruments and then buy properties later
                        </li>
                        <li class="investing__nested-list-item">
                            recommended division of the financial instruments part is:
                        </li>
                        <li class="investing__nested-list-item">
                            40% in inflation-indexed treasury bonds
                        </li>
                        <li class="investing__nested-list-item">
                            30% in shares (both developed and developing markets)
                        </li>
                        <li class="investing__nested-list-item">
                            20% in treasury bonds listed on the market
                        </li>
                        <li class="investing__nested-list-item">
                            10% in investment gold
                        </li>
                    </ul>
                </li>

                <li class="investing__list-item investing__list-item--bigger-text">
                    offensive portfolio
                    <ul class="investing__nested-list">
                        <li class="investing__nested-list-item">
                            additional portfolio, which consists of money we can afford to lose
                        </li>
                        <li class="investing__nested-list-item">
                            consists of assets of higher risk, but also higher potential return
                        </li>
                        <li class="investing__nested-list-item">
                            good option if you want to spend more time on investing and utilize your knowledge in
                            harsh market conditions
                        </li>
                        <li class="investing__nested-list-item">
                            here you can be more flexible with wages and try to predict the prices of assets, it's
                            hard, but possible
                        </li>
                    </ul>
                </li>
            </ul>
        </section>

        <section class="page__section" id="set-of-basic-rules">
            <h2 class="page__section-header">
                Set of basic rules
            </h2>

            <ul class="investing__list">
                <li class="investing__list-item">
                    the economy and markets are cyclical
                </li>

                <li class="investing__list-item">
                    don't put all your eggs into one basket - every few or a dozen or so years there is a time that
                    is catastrophic for one of the asset classes, so diversify your portfolio
                </li>

                <li class="investing__list-item">
                    buy low, sell high
                </li>

                <li class="investing__list-item">
                    be greedy when others are fearful, be fearful when others are greedy; buy when blood is spilling
                </li>

                <li class="investing__list-item">
                    it is not profitable to hold large sums of cash in the long term, most assets bring higher rates
                    of return
                </li>

                <li class="investing__list-item">
                    controlling emotions and mental state is often more important than knowledge
                </li>

                <li class="investing__list-item">
                    no one knows the future, don't trust back analysis
                </li>

                <li class="investing__list-item">
                    everyone has a different tendency to take risks
                </li>
            </ul>
        </section>
    </article>
</main>