<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Project P.F.I - 404 - Resource Not Found</title>
</head>

<body>
    <h1>
        404
    </h1>

    <h2>
        Resource not found
    </h2>
</body>

</html>